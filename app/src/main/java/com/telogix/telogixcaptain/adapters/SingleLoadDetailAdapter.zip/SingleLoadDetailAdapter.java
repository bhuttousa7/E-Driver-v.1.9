package com.telogix.telogixcaptain.adapters;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.telogix.telogixcaptain.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SingleLoadDetailAdapter extends BaseAdapter {
    Context context;
    List<HashMap> singleLoadDetailList = new ArrayList<HashMap>();
    LayoutInflater layoutInflater;

    public SingleLoadDetailAdapter(Context context, List singleLoadDetailList){
        this.context = context;
        this.singleLoadDetailList = singleLoadDetailList;
        layoutInflater = LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        return (singleLoadDetailList.size() * 2);
    }

    @Override
    public Object getItem(int i) {
        return singleLoadDetailList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View view1 = layoutInflater.inflate(R.layout.singleload_view_detail_item,null,false);
        TextView singleloadtextview = view1.findViewById(R.id.singleloadtextview);
        singleLoadDetailList.get(i).forEach((key,value) ->{
            String k = String.valueOf(key);
            String v = String.valueOf(value);

            if(i%2 == 0){
                if(i == 0){
                    singleloadtextview.setText(k);
                }
                else{
                    singleloadtextview.setText(k);
                }

            }
            else{
                singleloadtextview.setText(v);
            }



        });


        return view1;
    }
}
